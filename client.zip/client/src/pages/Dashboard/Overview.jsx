import React from 'react'
import MenteesCard from '../../components/mentor/components/MenteesCard'
import Calendar from '../../components/mentor/components/Calendar'
import RequestCard from '../../components/mentor/components/RequestCard'

const Overview = () => {
  return (
    <div>
      <h1>Overview Page</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded shadow">Active Mentees: 5</div>
        <div className="bg-white p-4 rounded shadow">Upcoming Sessions: 3</div>
        <div className="bg-white p-4 rounded shadow">Average Rating: 4.8 ⭐</div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left - Mentees + Requests */}
        <div className="space-y-4">
          <MenteesCard/>
          <RequestCard/>
        </div>
    
    <Calendar/>
    </div>
    </div>
  )
}

export default Overview
