import React from 'react'
import Sidebar from '../../components/mentor/components/Sidebar'
import NavbarDashboard from '../../components/mentor/components/NavbarDashboard'
import { Outlet } from 'react-router-dom'

const MentorLayout = () => {
  return (
   
    <div>
      <Sidebar/>
      <div>
        <NavbarDashboard/>
        <main>
            <Outlet/>
        </main>
      </div>
    </div> 
  )
}

export default MentorLayout
