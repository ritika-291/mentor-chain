export default function Calendar() {
  return (
    <div className="bg-white p-4 rounded shadow">
      <h2 className="font-semibold mb-2">Calendar</h2>
      <p className="text-gray-500">[Calendar placeholder – upcoming sessions]</p>
    </div>
  );
}
