export default function MenteesCard() {
  return (
    <div className="bg-white p-4 rounded shadow">
      <h2 className="font-semibold mb-2">Your Mentees</h2>
      <ul className="space-y-2">
        <li className="border p-2 rounded">John Doe</li>
        <li className="border p-2 rounded">Jane Smith</li>
        <li className="border p-2 rounded">Alice Johnson</li>
      </ul>
    </div>
  );
}
