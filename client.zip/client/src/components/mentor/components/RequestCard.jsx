export default function RequestCard() {
  return (
    <div className="bg-white p-4 rounded shadow">
      <h2 className="font-semibold mb-2">Pending Requests</h2>
      <div className="border p-2 rounded">Request from Mark Wilson</div>
    </div>
  );
}
