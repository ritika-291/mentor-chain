import React from 'react'
import { NavLink } from 'react-router-dom';

const Sidebar = () => {

  const navItems = [
    { to:"/dashboard/overview",label:"Overview"},
    { to:"/dashboard/sessions",label:"Sessions"},
    { to:"/dashboard/request",label:"Request"},
    { to:"/dashboard/messages",label:"Messages"},
    { to:"/dashboard/profile",label:"Profile"},
    { to:"/dashboard/settings",label:"Settings"},
  ];


  return (
    <aside>
      <div>MentorChain</div>
      <nav>
        {navItems.map((item)=>(
          <NavLink 
          key={item.to}
          to={item.to}
          className={({isActive})=> 
            `block px-4 py-2 rounded-md ${
              isActive ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-200'}`
            }>
              {item.label}
            </NavLink>
        ))
            
          }
      </nav>
    </aside>
  )
}

export default Sidebar
