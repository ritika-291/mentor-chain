// NavbarDashboard.jsx
import React from 'react';

const NavbarDashboard = () => {
 

  return (
      <header className="h-14 bg-white shadow flex items-center justify-between px-6">
      {/* Search Bar */}
      <input
        type="text"
        placeholder="Search..."
        className="border rounded-md px-3 py-1 w-64"
      />
       <div className="flex items-center gap-3">
        <span className="text-gray-700">Hello, Mentor</span>
        <img
          src="https://via.placeholder.com/35"
          alt="profile"
          className="w-9 h-9 rounded-full"
        />
      </div>
    </header>
  );
};

export default NavbarDashboard;