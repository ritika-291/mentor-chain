import React from 'react'
import Home from './pages/Home'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
// import Login from './pages/Login'
// import SignUp from './pages/SignUp'
// import MentorLayout from './pages/Dashboard/MentorLayout'




const App = () => {
  
  const router=createBrowserRouter([
    {
       path:'/',
       element:<Home/>
    },
  //  {
  //      path:'/login',
  //      element:<Login/>
  //   },
  //   {
  //      path:'/signup',
  //      element:<SignUp/>
  //   },
  //   {
  //     path: '/mentor',
  //     element: <MentorLayout />,
  //     children: [
  //       { index: true, element: <div>Mentor Dashboard Content</div> }, // Placeholder
  //       // ... other mentor dashboard routes
  //     ],
  //   }
   
  ])
  return (
    <RouterProvider router={router}></RouterProvider>
  )
}

export default App;