
const mentorData = [
  {
    title: "Find a Mentor",
    subtitle: "Register now",
    image: "https://mentoree.com/public/assets/app/img/find_mentor.png", // place this in public/assets
    link: "/find-mentor"
  },
  {
    title: "Become a Mentor",
    subtitle: "Get Started",
    image: "https://mentoree.com/public/assets/app/img/become_mentor.png", // place this in public/assets
    link: "/become-mentor"
  }
];

export default mentorData;
